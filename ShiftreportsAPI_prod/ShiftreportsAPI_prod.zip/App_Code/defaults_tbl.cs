﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedliveDM.Models
{
    // Save the defaults values
    public class defaults_tbl
    {
        public int id { set; get; }
        public string name { set; get; }
        public string namevalues { set; get; }
    }
}
