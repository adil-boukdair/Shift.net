﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ExpensTrackerAPI.Controllers
{
    public class ReportReviewController : Controller
    {
        // GET: ReportReview
        public ActionResult Index()
        {
            return View();
        }
    }
}